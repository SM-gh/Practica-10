package com.example.alumnos.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.CheckBox;
import android.text.TextUtils;

public class MainActivity extends AppCompatActivity {

    private RadioButton radioButton1;
    private RadioButton radioButton2;
    private EditText editText1;
    private EditText editText2;
    private TextView textView1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText1 = (EditText) findViewById(R.id.txt_1);
        editText2 = (EditText) findViewById(R.id.txt_2);
        radioButton1 = (RadioButton) findViewById(R.id.radioButtonSuma);
        radioButton2 = (RadioButton) findViewById(R.id.radioButtonResta);
        textView1 = (TextView) findViewById(R.id.txt_Resultado);

    }

    public void Operacion(View view){

        String txt1String = editText1.getText().toString();
        String txt2String = editText2.getText().toString();

        double Resultado = 0;
        if(txt1String.isEmpty() || txt2String.isEmpty() )
        {
            String ResultadoString = "Ingresa todos los datos";
            textView1.setText(ResultadoString);
        }else if (txt1String.equals(".") || txt2String.equals("."))
        {
            String ResultadoString = "Algun elemento no es válido";
            textView1.setText(ResultadoString);
        }
        else
            {
                double tx1Double = Double.parseDouble(txt1String);
                double tx2Double = Double.parseDouble(txt2String);

                if(tx1Double>999.999||tx2Double>999.999)
                {
                    String ResultadoString = "Error: Máximo 3 cifras";
                    textView1.setText(ResultadoString);
                }
                else if(tx1Double<-999.999||tx2Double<-999.999)
                {
                    String ResultadoString = "Error: Máximo 3 cifras";

                    textView1.setText(ResultadoString);
                }
                else {
                    if (radioButton1.isChecked() == true) {
                        Resultado = tx1Double + tx2Double;

                    } else {
                        Resultado = tx1Double - tx2Double;
                    }
                    String ResultadoString = String.valueOf(Resultado);
                    textView1.setText(ResultadoString);
            }
        }
    }

    public void Borrar(View view)
    {
        editText1.setText("");
        editText2.setText("");

        String ResultadoString = "";

        textView1.setText(ResultadoString);
    }

}
